def sortList(unsortedList):
    for i in range(len(unsortedList)):
        min_idx = i
        for j in range(i + 1, len(unsortedList)):
            if unsortedList[min_idx] > unsortedList[j]:
                min_idx = j
        unsortedList[i], unsortedList[min_idx] = unsortedList[min_idx], unsortedList[i]

    return unsortedList