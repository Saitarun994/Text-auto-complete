import math
import sys

from bsearch import _binSearchRec
from sort import *


def main():
    # <<<cmd line input for file name>>>
    if(len(sys.argv)>1):
        filename = sys.argv[1]
    else:
        filename = "test.txt"
    # <<<end of filename assignment>>>

    # <<<<reading lines from file and arranging the words>>>
    with open(filename) as f:
        lines = f.readlines()
    words = [x.strip() for x in lines]
    words = sortList(words)
    # <<<<end of wordlist arrangement>>>
    print(words)
    print("*************************************************************************")
    print("Welcome to Auto-complete!\n", "Usage: Enter a prefix to auto-complete.\n",
          "Entering nothing will print the first word in the sorted list.\n", "Enter <QUIT> to exit.\n")
    print("*************************************************************************")

    user_input = input("Enter a Prefix to search for: ")
    if user_input.isnumeric():
        print("That's not an String!")
        user_input = input("Enter a Prefix to search for: ")


    while user_input != "<QUIT>":
        if user_input== "":
            print("Enter a valid prefix")
            print("List of words are:")
            print(words)
        else:
            _binSearchRec(words, user_input, 0, len(words))

        user_input = input("Enter a Prefix to search for: ")
        if user_input.isnumeric():
            print("That's not an String!")
            user_input = input("Enter a Prefix to search for: ")

    print("       END OF PREFIX SEARCH       ")



if __name__ == '__main__':
    main()

