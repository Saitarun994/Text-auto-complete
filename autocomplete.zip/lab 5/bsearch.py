import math


def _binSearchRec(sortedList,prefix,left,right):
    if(left>right):
        return -1

    midindex = math.floor((left + right) / 2)

    if (left == right):
        temp=sortedList[midindex]
        if temp[0:len(prefix)] != prefix:
            print("Unable to find given value")
            #exit()

    tempString = sortedList[midindex]
    if tempString[0:len(prefix)] == prefix:

        min = midindex
        i = midindex
        while i >= 0:
            temp = sortedList[i]
            if(temp[0:len(prefix)]==prefix):
                min=i
            else:
                break
            i = i-1
        print(sortedList[min])

    elif tempString[0:len(prefix)] < prefix:
        _binSearchRec(sortedList, prefix, midindex+1, right)
    else:
        _binSearchRec(sortedList, prefix, left, midindex-1)
